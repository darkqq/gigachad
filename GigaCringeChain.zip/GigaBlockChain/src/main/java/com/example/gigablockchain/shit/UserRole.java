package com.example.gigablockchain.shit;

public enum UserRole {
    ADMIN, USER;
}
