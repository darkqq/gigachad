package com.example.gigablockchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GigaBlockChainApplication {

    public static void main(String[] args) {
        SpringApplication.run(GigaBlockChainApplication.class, args);
    }

}
